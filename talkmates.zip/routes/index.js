const express = require('express');
const router = express.Router();

const user = require('./user');
const posts = require('./posts');

router.use('/users',user);
router.use('/posts', posts);

module.exports = router;