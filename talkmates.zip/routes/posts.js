const express = require('express');
const router = express.Router();
const upload = require('../fileUpload/image')
const { postList, postDetail,uploadImage } = require('../controller/posts');

router.get('/', postList);
router.post('/',upload.single('image'), postDetail);
// router.post('/uploadimage',upload.single('image'), uploadImage);

module.exports = router;