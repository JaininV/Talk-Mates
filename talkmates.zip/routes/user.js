const express = require('express');
const { validate, ValidationError, Joi } = require('express-validation');
const router = express.Router();


const {getAllUsers, getUserData, userLogin, addUser, forgetPassword, changePassword} = require('../controller/user');
const loginValidation = require('../validate/loginValidation')
const updatePasswordValidation =require('../validate/updatePassword')
const addUserValidation = require("../validate/addUser")

router.get('/', getAllUsers);
router.get('/userdata', getUserData);
router.post('/login', validate(loginValidation, {}, {}), userLogin);
router.post('/register',validate(addUserValidation, {}, {}), addUser);
router.get('/changepassword',validate(updatePasswordValidation, {}, {}),changePassword)
router.post('/forgetpassword', forgetPassword);


module.exports = router;
