const mongoose = require('mongoose');
const uri = "mongodb+srv://innovate369:admin123@talkmates.jobph.mongodb.net/talkmates?retryWrites=true&w=majority";
mongoose.connect(uri, {
  useNewUrlParser: true,
  useUnifiedTopology: true
})
  .then(() => {
    console.log('MongoDB Connected…')
  })
  .catch(err => console.log(err))

