const multer = require('multer');
const { uploadFile } = require('../aws/s3');
const Post = require('../model/posts');

const postList = (req, res) => {
    Post.find({}, (err, result) => {
        if (err) {
            console.log(err);
        }
        res.send(result);
    });
}

const postDetail = async (req, res) => {
    try {
        const file = req.file
        console.log(file);
        const result = await uploadFile(file)
        console.log(result);
        // res.send({ imagePath: `/${result.Key}` })
        console.log(result.Key);
        const { title, description, author } = req.body;

        const model = {
            'title': title,
            'description': description,
            'author': author,
            'image': result.Location,
        };
        const logic = validation(model);
        if (logic) {
            const data = new Post(model);
            data.save(function (err, result) {
                if (err) throw err;
                res.send({
                    msg: "Post Created..",
                    data: model,
                    status: 200
                })
            })
        }
    }
    catch {
        res.send("Something is wrong");
    }
}


const uploadImage = (req, res) => {
    
}

module.exports = { postList, postDetail, uploadImage };