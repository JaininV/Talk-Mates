const express = require('express');
const app = express();
var validator = require("email-validator");
const User = require('../model/user');
const { validate, ValidationError, Joi } = require('express-validation')

const getAllUsers = (req, res) => {
    User.find({}, (err, result) => {
        if (err) {
            console.log(err);
        }
        res.send(result);
    });
}

const getUserData = (req, res) => {
    const Id = "621f0ed59026a4b9541e464a";
    User.findById(Id, function (err, result) {
        if (err) {
            console.log("User not found");
        }
        res.send(result);
    });
}

const addUser = async (req, res) => {

    try {
        const data = {
            fullName,
            gender,
            ph_no,
            email,
            password
        } = req.body

        const splitName = data.fullName;
        const [firstName, lastName] = splitName.split(' ');

        const signup = new User({
            fullName,
            firstName,
            lastName,
            gender,
            ph_no,
            email,
            password
        })
        res.send({
            msg: "signUp successfully",
            data: signup,
            status: 200
        })

        const resultData = await signup.save();

    } catch (err) {
        console.log(err);
    };
}

const userLogin = async (req, res) => {
    try {
        let userEmail = req.body.email;
        let userPassword = req.body.password;

        // let login = validation(userEmail, userPassword);


        let query = { 'email': userEmail };
        const user = await User.findOne(query);
        if (user.password === userPassword) {
            res.send(user);
        }
        else {
            res.send('Password is incorrect')
        }

    }
    catch (error) {
        res.send('User not found ' + error);
    }
}


const changePassword = (req, res) => {
    const { newPassword, confirmPassword, email, oldPassword } = req.body;
    User.findOne({ 'email': email }, async function (err, result) {
        if (err) {
            res.send("User not found");
        }
        const UserEmail = result.email;
        const UserPassword = result.password;
        const UserName = result.fullName;
        // console.log(UserName);
        if (UserEmail == email && UserPassword == oldPassword) {
            if (newPassword == confirmPassword) {
                await User.updateOne({ 'email': UserEmail }, { 'password': newPassword });
                res.send("Dear " + UserName + " Password Update Successfull")
            } else {
                res.send(err);
            }
        } else {
            res.send("Old Password is incorrect....");
        }
    });
};

const forgetPassword = async (req, res) => {
    const { email, password, repassword } = req.body;
    let query1 = { 'email': email };

    const user = await User.findOne(query1);
    if (user.email === email) {
        if (password === repassword) {
            let query = { 'password': password };
            const update = await User.updateOne(query1,query);
            res.send('Password change');
        }
        else {
            res.send('Password is not match');
        }
    }
    else {
        console.log("Email Id is incorrect...")
        res.send('email Is not valid');
    }
}

module.exports = { getAllUsers, getUserData, addUser, userLogin, changePassword, forgetPassword};
