const express = require('express');
const app = express();
const { validate, ValidationError, Joi } = require('express-validation')

const addUserValidation = {
    body: Joi.object({
        fullName: Joi.string()
            .messages({ 'string.pattern.base': `Enter your fullname` })
            .required(),
        gender: Joi.string()
            .regex(/[a-zA-Z0-9]{3,30}/)
            .required(),
        ph_no: Joi.string()
            .length(10)
            .pattern(/^[0-9]+$/)
            .required(),
        email: Joi.string()
            .email()
            .required(),
        password: Joi.string()
            .regex(/[a-zA-Z0-9]{3,30}/)
            .required(),
    }),
}



module.exports = addUserValidation;