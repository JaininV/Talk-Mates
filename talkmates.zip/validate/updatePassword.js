const { validate, ValidationError, Joi } = require('express-validation')

const updatePasswordValidation = {
    body: Joi.object({
        email: Joi.string()
            .email()
            .required(),
        oldPassword: Joi.string()
            .regex(/[a-zA-Z0-9]{3,30}/)
            .required(),
        newPassword: Joi.string()
            .regex(/[a-zA-Z0-9]{3,30}/)
            .required(),
        confirmPassword: Joi.string()
            .regex(/[a-zA-Z0-9]{3,30}/)
            .required(),
    }),
}

module.exports = updatePasswordValidation;