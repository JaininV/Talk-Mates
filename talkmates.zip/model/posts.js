const mongoose = require('mongoose');

const Post = new mongoose.Schema({
    title: 'string',
    description: 'string',
    author: 'string',
    image: 'string',
    date: {
        type: Date,
        default: Date.now
    },
});
const posts = mongoose.model('posts', Post);

module.exports = posts;