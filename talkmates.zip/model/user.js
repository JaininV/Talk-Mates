const mongoose = require('mongoose');

const User = new mongoose.Schema({ 
    fullName: 'string',
    firstName: 'string',
    lastName: 'string',
    gender: 'string',
    ph_no: 'number',
    email: 'string',
    password: 'string',
    date:{
        type: Date,
        default:Date.now
    }  });
const users = mongoose.model('users', User);

module.exports = users;