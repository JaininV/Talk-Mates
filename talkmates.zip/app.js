const express = require('express');
const cors = require('cors');
const db = require('./config/db');
const app = express();
const router = require('./routes/index');
const { validate, ValidationError, Joi } = require('express-validation')

app.use(express.json());
app.use(express.urlencoded({ extended: true, type: "application/x-www-form-urlencoded" }));
// app.use(express.urlencoded({ extended: true, type: "application/form-data" }));

app.use(cors());


app.use('/api', router);

app.use((err, req, res, next) => {
    if (err instanceof ValidationError) {
        return res.status(err.statusCode).json(err)
    }
    return res.status(500).json(err)
})

app.listen(3001, () => {
    console.log("Server connected...");
})

